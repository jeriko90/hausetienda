<?php

/**
 * Pantalla de ajustes
 * copyright Enrique J. Ros - enrique@enriquejros.com
 *
 * @author 			Enrique J. Ros
 * @link 			https://www.enriquejros.com/plugins/plugin-pedido-minimo-woocommerce/
 * @since 			2.0.0
 * @package 		PedidoMinimoWoo
 *
 */

if (!class_exists ('Opciones_Pedido_Minimo_Woo')) :

	Class Opciones_Pedido_Minimo_Woo {

		public function __construct () {

			if (!is_admin())
				return;

			add_action ('admin_menu', [$this, 'crea_menu_opciones'], 10);
			add_action ('admin_init', [$this, 'registra_opciones'], 10);
			add_action ('admin_enqueue_scripts', [$this, 'estilos_opciones'], 10);
			}

		public function crea_menu_opciones () {

			add_options_page (__('Pedido mínimo', 'pedido-minimo'), __('Pedido mínimo', 'pedido-minimo'), 'manage_options', 'pedido-minimo', [$this, 'pedido_minimo_opciones']);
			}

		public function registra_opciones () {

			register_setting ('pedido-minimo', 'ejr_minimos_pedido');
			}

		public function pedido_minimo_opciones () {

			current_user_can ('manage_options') or wp_die (__('Sorry, you are not allowed to access this page.'));

			?>

				<div class="wrap">

				<h2 class="opciones"><?php _e('Establecer un pedido mínimo para WooCommerce', 'pedido-minimo'); ?></h2>

					<form method="post" action="options.php" id="opciones">

						<?php

							settings_fields ('pedido-minimo');
							do_settings_sections ('pedido-minimo');

							$ajustes = Clase_Pedido_Minimo_Woo::recupera_minimos();
						?>

						<table class="form-table">

							<tr valign="top">
								<th scope="row"><?php _e('Cantidad mínima por rol de usuario (0 para desactivar)', 'pedido-minimo'); ?></th>
								<td>

									<?php

										foreach ($this->recupera_roles() as $rol => $nombre_rol) :

										?>

											<input type="number" name="ejr_minimos_pedido[<?php echo $rol; ?>]" value="<?php echo $ajustes[$rol]; ?>" min="0" step="0.1" style="text-align:right;"><?php printf (' %s %s', get_woocommerce_currency_symbol(), translate_user_role ($nombre_rol)); ?><br />

										<?php endforeach; ?>

								</td>
							</tr>

							<tr valign="top">
								<th scope="row"><?php _e('Calcular el mínimo...', 'pedido-minimo'); ?></th>
								<td>
									<div class="excluye"><input type="radio" name="ejr_minimos_pedido[excluye]" value="1" <?php checked ($ajustes['excluye'], 1); ?>> <?php _e('Sin incluir gastos de envío', 'pedido-minimo'); ?></div><br />
									<div class="excluye"><input type="radio" name="ejr_minimos_pedido[excluye]" value="0" <?php checked ($ajustes['excluye'], 0); ?>> <?php _e('Incluyendo gastos de envío', 'pedido-minimo'); ?></div>
								</td>
							</tr>

							<tr valign="top">
								<th scope="row"><?php _e('Mensaje de aviso', 'pedido-minimo'); ?></th>
								<td>
									<input type="text" name="ejr_minimos_pedido[error]" value="<?php echo $ajustes['error']; ?>" style="width:500px;max-width:90%;"><br />
									<?php _e('%min% se sustituirá por la cantidad de pedido mínimo correspondiente al rol y %actual% por el valor del contenido del carrito.', 'pedido-minimo'); ?>
								</td>
							</tr>

						</table>

						<?php submit_button(); ?>

						<p><a class="button" target="_blank" href="https://www.novaweb.cl/soporte/"><i class="fa fa-cog fa-spin"></i> <?php _e('Soporte', 'pedido-minimo'); ?></a></p>

					</form>
				</div>

			<?php
			}

		private function recupera_roles () {

			$roles = [];

			foreach (get_editable_roles() as $rol => $rol_info)
				$roles[$rol] = $rol_info['name'];

			$roles['invitado'] = __('Invitado', 'pedido-minimo');

			return $roles;
			}

		public function estilos_opciones () {

			if (isset ($_GET['page']) && 'pedido-minimo' == $_GET['page']) {
				
				wp_enqueue_style ('pedido-minimo-opciones', plugins_url ('assets/css/opciones2.min.css', __FILE__));
				wp_enqueue_style ('fontawesome', plugins_url ('assets/css/font-awesome.min.css', __FILE__));
				}
			}

		}

endif;