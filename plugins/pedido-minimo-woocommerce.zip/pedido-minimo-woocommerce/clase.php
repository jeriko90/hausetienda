<?php

/**
 * copyright Novaweb - webmaster@novaweb.cl
 *
 * @author 			Novaweb
 * @link			https://www.novaweb.cl
 * @since			2.0.0
 * @package			PedidoMinimoWoo
 *
 */

if (!class_exists ('Clase_Pedido_Minimo_Woo')) :

	Class Clase_Pedido_Minimo_Woo {

		public function __construct () {

			add_action ('woocommerce_checkout_process', [$this, 'pedido_minimo'], 10);
			add_action ('woocommerce_before_cart', [$this, 'pedido_minimo'], 10);
			}

		public function pedido_minimo () {

			$ajustes = $this->recupera_minimos();

			global $woocommerce;

			$usuario = wp_get_current_user();
			$rol     = count ($usuario->roles) ? $usuario->roles[0] : 'invitado';

			if (apply_filters ('pedido_minimo_recogida_local', false, $rol) && 'local_pickup' === substr ($_POST['shipping_method'][0], 0, 12))
				return;

			/**
			 * Permitir un pedido sin mínimo si se selecciona recogida local como método de envío:
			 *
			 * add_filter ('pedido_minimo_recogida_local', '__return_true');
			 *
			 */

			$minimo = $ajustes[$rol] ? : $ajustes['minimo']; //Compatibilidad con versiones 1.x
			$tienda = apply_filters ('woocommerce_continue_shopping_redirect', get_permalink (wc_get_page_id ('shop')));
			$envio  = round ($woocommerce->cart->shipping_total + $woocommerce->cart->shipping_tax_total, 2);
			$actual = round ($woocommerce->cart->total, 2);

			if ($ajustes['excluye'])
				$actual -= $envio;

			$frase = str_replace (['%min%', '%actual%'], [wc_price ($minimo), wc_price ($actual)], $ajustes['error']);

			if ($minimo && ($actual < $minimo)) {

				if (is_cart()) {

					wc_print_notice (sprintf ('%s <a style="float:right;" class="button wc-forward" href="%s">%s</a><div style="clear:both;"></div>', $frase, $tienda, __('Continue shopping', 'woocommerce')), 'error');

					/**
					 * Ocultar el botón Finalizar compra en la página de carrito si no se ha alcanzado el mínimo:
					 *
					 * add_filter ('pedido_minimo_ocultar_finalizar_compra', '__return_true');
					 *
					 */

					if (apply_filters ('pedido_minimo_ocultar_finalizar_compra', false, $rol))
						echo '<style>.wc-proceed-to-checkout{display:none!important}</style>';
					}

				else
					wc_add_notice (sprintf ('%s <a style="float:right;" class="button wc-forward" href="%s">%s</a><div style="clear:both;"></div>', $frase, $tienda, __('Continue shopping', 'woocommerce')), 'error');
				}

			return;
			}

		public static function recupera_minimos () {

			if ($array_ajustes = get_option ('ejr_minimos_pedido'))
				return $array_ajustes;

			global $wp_roles; //get_editable_roles() no está disponible fuera de wp-admin

			foreach (apply_filters ('editable_roles', $wp_roles->roles) as $rol => $datos_rol)
				$array_ajustes[$rol] = get_option ('ejr_minimo_' . $rol);

			$array_ajustes['invitado'] = get_option ('ejr_minimo_invitado');
			$array_ajustes['minimo']   = get_option ('ejr_minimo'); //Compatibilidad con versiones 1.x
			$array_ajustes['error']    = strlen ($frase = esc_attr (get_option ('ejr_frase_min'))) ? $frase : __('El pedido m&iacute;nimo es de %min%, actualmente su pedido es de %actual%', 'pedido-minimo');
			$array_ajustes['excluye']  = get_option ('ejr_excluye') ? : 1;

			update_option ('ejr_minimos_pedido', $array_ajustes);

			return $array_ajustes;
			}

		}

endif;